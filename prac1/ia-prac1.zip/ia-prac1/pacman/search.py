# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
import Node
import sys


class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return [s, s, w, s, w, w, s, w]


def depthFirstSearch(problem):
    node = Node.Node(problem.getStartState())
    fringe = util.Stack()
    fringe.push(node)
    generated = {}  # Dictionary of expanded nodes
    while True:
        if fringe.isEmpty():
            sys.exit(-1)
        n = fringe.pop()
        generated[n] = ['E', n]
        for state, action, cost in problem.getSuccessors(n.state):
            newNode = Node.Node(state, n, action, cost)
            if problem.isGoalState(newNode.state):
                return newNode.path()
            if newNode not in generated and newNode not in fringe.list:
                fringe.push(newNode)
                generated[newNode] = ['F', n]


def breadthFirstSearch(problem):
    """
    :param problem:
    :return:
    """

    """Search the shallowest nodes in the search tree first."""
    node = Node.Node(problem.getStartState())
    fringe = util.Queue()
    fringe.push(node)
    generated = {}  # Dictionary of expanded nodes
    while True:
        if fringe.isEmpty():
            sys.exit(-1)
        n = fringe.pop()
        generated[n] = ['E', n]
        for state, action, cost in problem.getSuccessors(n.state):
            newNode = Node.Node(state, n, action, cost)
            if problem.isGoalState(newNode.state):
                return newNode.path()
            if newNode not in generated and newNode not in fringe.list:
                fringe.push(newNode)
                generated[newNode] = ['F', n]


def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    return versatileSearch(problem, nullHeuristic, True)


def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0


def diagonalDistanceHeuristic(state, problem):
    """
    Like the manhattan heuristic but avoiding 90 degree edges.
    In other words, pacman can now move diagonally.

    :param state: position of pacman
    :param problem:
    :return: estimated cost with diagonal distance
    """
    cost = 1  # cost per movement
    dx = abs(state[0] - 1)  # 1 is the position of the food
    dy = abs(state[1] - 1)
    return cost * (dx + dy) + (cost - 2 * cost) * min(dx, dy)


def bestFirstSearchH(problem, heuristic=nullHeuristic):
    return versatileSearch(problem, heuristic, False)


def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    return versatileSearch(problem, heuristic, True)


def versatileSearch(problem, heuristic=nullHeuristic, gN=True):  # UCS by default

    fringe = util.PriorityQueue()
    startNode = Node.Node(problem.getStartState())

    fringe.push(startNode, startNode.fn)

    generated = {}
    while True:
        if fringe.isEmpty():
            sys.exit(-1)
        n = fringe.pop()
        if problem.isGoalState(n.state):
            return n.path()
        if (n, 'E') not in generated.items():
            generated[n] = 'E'
            for state, action, cost in problem.getSuccessors(n.state):

                newNode = Node.Node(state, n, action, cost)
                if gN:
                    pm = pathMax(n.fn, newNode.cost*gN, heuristic(newNode.state, problem))
                    newNode.fn = newNode.cost * gN + pm
                if not gN:
                    newNode.fn = heuristic(newNode.state, problem)

                if newNode not in generated:  # not in fringe and not in expanded
                    fringe.push(newNode, newNode.fn)
                    generated[newNode] = 'F'
                elif (newNode, 'F') in generated.items():
                	fringe.push(newNode, newNode.fn)
                	generated[newNode] = 'F'


def pathMax(pFn, gN, hN):
    return max(pFn, gN + hN)


def bidirectionalSearch(problem):
    # Init both fringes and generated structures
    # Front starts at the start state
    # Back starts at the goal (1,1)

    fringeFront = util.Queue()
    fringeBack = util.Queue()
    generatedFront = {}
    generatedBack = {}

    frontNode = Node.Node(problem.getStartState())
    fringeFront.push(frontNode)
    generatedFront[frontNode] = [frontNode, 'F']
    backNode = Node.Node((1, 1))
    fringeBack.push(backNode)
    generatedBack[backNode] = [backNode, 'F']
    while True:
        if fringeFront.isEmpty() and fringeBack.isEmpty():
            sys.exit(0)

        # First BFS (expanding from start)
        n = fringeFront.pop()
        generatedFront[n] = [n, 'E']
        for state, action, cost in problem.getSuccessors(n.state):
            newNode = Node.Node(state, n, action, cost)
            # Check if the two fringes intersect
            if ((newNode, [newNode, 'F']) in generatedBack.items()):
                pathFront = newNode.path()
                backNode = generatedBack[newNode][0]
                pathBack = invertPath(backNode.path())
                return pathFront + pathBack
            if newNode not in generatedFront:
                fringeFront.push(newNode)
                generatedFront[newNode] = [newNode, 'F']  # Add node to fringe

        # Second BFS (expanding from goal)
        n = fringeBack.pop()
        generatedBack[n] = [n, 'E']
        for state, action, cost in problem.getSuccessors(n.state):
            newNode = Node.Node(state, n, action, cost)
            # Check if the two fringes intersect
            if ((newNode, [newNode, 'F']) in generatedFront.items()):
                pathBack = invertPath(newNode.path())
                frontNode = generatedFront[newNode][0]
                pathFront = frontNode.path()
                return pathFront + pathBack
            if newNode not in generatedBack:
                fringeBack.push(newNode)
                generatedBack[newNode] = [newNode, 'F']  # Add node to expanded

def invertPath(path):
    inverted = []
    for dir in path:
        if dir == 'North': inverted.append('South')
        if dir == 'South': inverted.append('North')
        if dir == 'East': inverted.append('West')
        if dir == 'West': inverted.append('East')
    inverted.reverse()
    return inverted




# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
bfsh = bestFirstSearchH
bds = bidirectionalSearch
custH = diagonalDistanceHeuristic
