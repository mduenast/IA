class Node(object):
    def __init__(self, state, parent=None, action=None, cost=0, fn=0):
        self.state = state
        self.parent = parent
        self.action = action
        self.cost = cost
        self.fn = fn

    def __str__(self):
        return "-- Node {0} --\n Parent: {1}\n Action: {2}\n Cost: {3}" \
            .format(self.state, self.parent, self.action, self.cost)

    def __hash__(self):
        return hash(self.state)

    def __eq__(self, other):
        if type(other) == Node and type(other) == Node:
            return self.state == other.state
        return -1

    def path(self):
        currentNode = self
        actionList = list()

        while currentNode.parent != None:
            actionList.append(currentNode.action)
            currentNode = currentNode.parent

        actionList.reverse()
        return actionList

if __name__ == '__main__':
    n0 = Node((0,0))
    n1 = Node((5,0), n0, "Fill A", 1)
    n2 = Node((5,3), n1, "Fill B", 1)
    n3 = Node((0,3), n2, "Empty A", 1)
    actions = n3.path()
    print actions