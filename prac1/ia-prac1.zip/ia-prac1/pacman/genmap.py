import sys
import random

def main():
    #Rescue args
    args = sys.argv

    global n, m

    n = int(args[1])
    m = int(args[2])
    prob = int(args[3])
    seed = args[4]

    random.seed(seed)

    #Generate coords for pacman and food
    pacman = (random.randint(1, n-2), random.randint(1, m-2))
    food   = (n-2,1)

    #Make sure pacman and food don't overlap
    #while pacman == food:
    #    food = (random.randint(1, n-2), random.randint(1, m-2))

    #Place elements: walls, pacman, food
    for i in range(n):
        for j in range(m):
            if isBorder(i, j):
                #print "%",
		sys.stdout.write('%')
            elif pacman == (i, j):
                #print "P",
		sys.stdout.write('P')
            elif food == (i,j):
                #print ".",
		sys.stdout.write('.')
            else:
                if random.randint(1, 100) <= prob:
                    #print "%",
		    sys.stdout.write('%')
                else:
                    #print " ",
		    sys.stdout.write(' ')
        print ""

def isBorder(i, j):
    return i==0 or i==n-1 or j==0 or j==m-1


if __name__ == '__main__':
    main()
