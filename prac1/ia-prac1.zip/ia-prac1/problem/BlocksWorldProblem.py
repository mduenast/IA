from copy import deepcopy

"""
Para resolver el problema utilizariamos el algoritmo A*

No hemos podido implementarlo para edulog 
"""

class BlocksWorldProblem:

	def __init__(self, c, positions = [], goalPositions = []):

		# number of blocks
		self.k = 0
		for m in positions:
			self.k += len(m)
		# number of positions
		self.m = len(positions)
		# max blocks on position
		self.c = c
		# number of positions
		self.positions = positions
		# goal positions
		self.goalPositions = goalPositions

	def get_start_states(self):
		return [(self.positions)]

	def is_goal_state(self, state):
		return self.goalPositions == state[0]

	def is_valid_state(self, state):
		for m in state:
			if len(m) > self.c:
				return False
		return True

	def move(self, state, posO, posD):
		if len(state[0][posO]) > 0:
			newState = deepcopy(state)
			co = newState[0][posO].pop()
			newState[0][posD].append(co)
			return newState
		return None

class CustomHeuristic:
	# Number of blocks missplaced

	def compute(self, state):
		unequal = 0
		for i in range(0,len(state)):
			for j in range(0,len(state[i])):
				if state[i][j] != self.goal[i][j]:
					unequal += 1;
		return unequal