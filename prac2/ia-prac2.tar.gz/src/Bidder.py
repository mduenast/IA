# Represents an auctioneer and his bids

class Bidder(object):

	def __init__(self):
		self.bids = []

	def add_bid(self, bid=[]):
		self.bids.append(bid)

	def __str__(self):
		string = "Bids:\n"
		for bid in self.bids:
			string += " --- " + str(bid) + "\n"
		return string