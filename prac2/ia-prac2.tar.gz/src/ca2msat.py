#!/usr/bin/env python
# -*- coding: utf-8 -*-

import itertools
import argparse
import auction_parser
import Bidder
import wcnf
import os

# Main
##############################################################################

def main(opts):

	# Rescue parsed arguments
	auction_path = opts.auction
	formula_path = opts.formula
	result_path  = opts.result
	solver_path  = opts.solver
	alo = opts.accept_at_least_one
	amo = opts.accept_at_most_one
	t13 = opts.transform_to_1_3_wpm

	# Parse auction file
	auct_parser = auction_parser.AuctionParser()

	n_goods, n_bids, bidders = auct_parser.parse_auction(auction_path);

	wc = wcnf.WCNFFormula() # Create a new formula	

	# add new_vars to formula, one for each bid
	for _ in range(n_bids):
		wc.new_var()

	list_bids = [] # List of bids, contains number of bid and items 

	for bidder in bidders:
		if amo: 
			# One bidder can only win on set of items
			accept_at_most_one(wc, bidder)
		if alo:
			# Each bidder has to win at least one set
			accept_at_least_one(wc, bidder)
		for bid in bidder.bids:
			# Store bids in the list
			list_bids.append([bid[0] + 1, set(bid[2:])])
			wc.add_clause([bid[0] + 1], bid[1]) # Add soft clause (n_bid, price)

	for bid1, bid2 in (itertools.combinations((bid for bid in list_bids), 2)):
		# check intersection of items
		if len(bid1[1] & bid2[1]) > 0: 
			# The bids have items in common, add exclusion clause
			wc.add_clause([bid1[0] * -1, bid2[0] * -1], 0)

	wcnf_formula = wc.to_1_3_wpm() if t13 else wc # Conver formula to 1-3 if necessary
	wcnf_formula.write_dimacs_file(formula_path) 
	# Execute solver and store result in temporal result
	command_to_exec = solver_path + " " + formula_path + " > tmp.txt"
	os.system(command_to_exec)

	# Parse and write result
	write_result(result_path, n_bids, t13)

def accept_at_most_one(wcnfFormula, bidder):
	# print "amo"
	bids = [bid[0] + 1 for bid in bidder.bids]
	wcnfFormula.add_at_most_one(bids, 0)

def accept_at_least_one(wcnfFormula, bidder):
	# print "alo"
	bids = [bid[0] + 1 for bid in bidder.bids]
	wcnfFormula.add_at_least_one(bids, 0)

def write_result(result_path, n_bids, t13):
	tmp = open("tmp.txt", 'r')
	result = open(result_path, 'w')
	reader = (l for l in tmp if l)
	for line in reader:
		if 's' in line:
			if "UNSATISFIABLE" in line:
				result.write("b NO SOLUTION\n")
		elif 'v' in line:
			accepted_bids = (int(i) for i in line[1:-1].split()) # Skip first character 'v' and '\n'
			result.write("b")
			for val in accepted_bids:
				# write only accepted bids
				# don't write reification variables
				if abs(val) <= n_bids and val >= 0:
					result.write(" ")
					result.write(str(abs(val) - 1))
			result.write("\n")
	tmp.close()
	result.close()

# Script entry point
###############################################################################

if __name__ == '__main__':
	parser = argparse.ArgumentParser(
		formatter_class=argparse.ArgumentDefaultsHelpFormatter,
		description="", epilog="")

	parser.add_argument('-a', '--auction', type=str, required=True,
						help="Combinatorial auction file")

	parser.add_argument('-f', '--formula', type=str, required=True,
						help="Wcnf formula file path")

	parser.add_argument('-r', '--result', type=str, required=True, 
						help="Result file path")

	parser.add_argument('-s', '--solver', type=str, required=True,
						help="Path to the WPM3 solver")

	parser.add_argument('-alo', '--accept-at-least-one', action='store_true',
						help="Accept at least one bid from each agent")

	parser.add_argument('-amo', '--accept-at-most-one', action='store_true',
						help="Accept at most one bid from each agent")

	parser.add_argument('-t13', '--transform-to-1-3-wpm', action='store_true',
						help="Transform the final formula to 1,3-WPM")

	main(parser.parse_args())