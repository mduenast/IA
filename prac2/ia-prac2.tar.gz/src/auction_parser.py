import sys
from Bidder import Bidder

class AuctionParser(object):

	def __init__(self):
		self.n_goods = 0
		self.n_bids = 0
		self.n_dummys = 0
		self.max_good = 0
		self.bidders = [] # list of Auctioneer instances each with its respective bids

	def parse_auction(self, auction_file):
		fd = open(auction_file, "r")
		reader = (l.strip() for l in fd)
		for line in (l for l in reader if (l and '%' not in l)):
			split_line = line.split()
			if split_line[0] == "goods":
				self.n_goods = int(split_line[1])
				self.max_good = self.n_goods - 1
			elif split_line[0] == "bids":
				self.n_bids = int(split_line[1])
			elif split_line[0] == "dummy":
				pass
			else:
				del split_line[-1] # Remove last token: '#', it is not needed
				bid = [self.parse_token(x) for x in split_line]
				if bid[-1] < self.n_goods: # Bidder with only a bid
					bidder = Bidder()
					bidder.add_bid(bid)
					self.bidders.append(bidder)
				elif bid[-1] > self.n_goods - 1 and bid[-1] == self.max_good: # Dummy detected
					# Delete last number, represents the dummy
					del bid[-1]
					# Add the bid to the las auctioneer
					self.bidders[-1].add_bid(bid)
				else: # bid[-1] > self.max_good
					# New dummy
					self.max_good = bid[-1]
					# Delete last number, represents the dummy
					del bid[-1]
					bidder = Bidder()
					bidder.add_bid(bid)
					self.bidders.append(bidder)
		fd.close()
		
		return self.n_goods, self.n_bids, self.bidders

	def parse_token(self, token):
		try:
			return int(token)
		except ValueError:
			return float(token)